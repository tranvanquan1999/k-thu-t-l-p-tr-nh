# viết chương trình kiểm tra số chẵn lẻ in ra màn hình
n=int(input("nhap so can kiem tra---->"))
if n % 2==0:
    print("so chan");
else:
    print("so le ")