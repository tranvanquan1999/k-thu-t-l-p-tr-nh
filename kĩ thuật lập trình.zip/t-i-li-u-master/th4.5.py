ds=input('nhap chuoi:').split()
ds.append('abc')
for ch in ds:
  print(ch)