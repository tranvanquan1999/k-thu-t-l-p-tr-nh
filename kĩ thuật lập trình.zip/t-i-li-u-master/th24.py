# viết chương trình nhập số tự nhiên n>0, in ra màn hình các số tự nhiên giảm dần ừ n đến 0 mỗi kí tự in trên một hàng
n=int(input("nhap so tu nhien n>0:"))
while n>=0:
    print(n);
    n=n-1;