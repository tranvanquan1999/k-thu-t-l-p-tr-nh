ds=input('danh sach:').split()
ds.reverse()
print(ds)
for so in ds:
    print(so)