#viết hàm sum tính tổng hai số
def sum(a,b):
    print("sum=" + str(a + b))
   #tong hai so 4 và 5
    sum(4,5)
    #tong hai so 3 va 7
    sum(3,7)